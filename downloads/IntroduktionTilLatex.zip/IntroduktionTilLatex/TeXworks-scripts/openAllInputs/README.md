"OpenAllInputs" script for TeXworks

Description
===========

This script allows the user to open all included documents.


Prerequisites
=============

- [TeXworks](http://www.tug.org/texworks/)



Installation
============

Simply put the script file into the "scripts" folder (or one of its subfolders).
You can find the "scripts" folder most easily by using the "Scripts > Scripting
TeXworks > Show Scripts Folder" menu item in TeXworks itself.
Afterwards, you need to click on "Scripts > Scripting TeXworks > Reload Script
List" or restart TeXworks.



Usage
=====

If you want to open a specific file, place the cursor inside the include / input statement that points to the file and activate the script.

