To complete installation of magicComments and logparser, run the following git commands.
git submodule init
git submodule update