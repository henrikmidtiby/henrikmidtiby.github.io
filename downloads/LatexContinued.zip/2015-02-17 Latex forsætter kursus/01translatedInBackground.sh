#!/bin/sh
 
latexmk -pdf -pvc advancedlatex.tex
