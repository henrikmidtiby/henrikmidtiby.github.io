<map version="freeplane 1.3.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Latex kurser" ID="ID_1723255651" CREATED="1283093380553" MODIFIED="1454656122235"><hook NAME="MapStyle">
    <properties show_icon_for_attributes="true" show_note_icons="true"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node">
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right">
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="fork" MAX_WIDTH="600">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
<font SIZE="10"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<attribute NAME="usepackage" VALUE="hsmpresentation"/>
<font ITALIC="true"/>
<node TEXT="\LaTeX - forts&#xe6;tterkursus" POSITION="right" ID="ID_1478305903" CREATED="1418549464650" MODIFIED="1454656111802">
<attribute NAME="author" VALUE="Henrik Skov Midtiby"/>
<attribute NAME="date" VALUE="2015-02-11 "/>
<node TEXT="Tilpasning af \LaTeX" ID="ID_1944298718" CREATED="1418652535878" MODIFIED="1454664259858">
<node TEXT="M&#xe5;let med i aften" ID="ID_1462463948" CREATED="1421325969122" MODIFIED="1454664259861">
<node TEXT="M&#xe5;let med i aften" ID="ID_1820951604" CREATED="1421325998011" MODIFIED="1454664418982"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Mindre b&#248;vl med latex dokumenter
    </p>
    <p>
      \item Bedre fejls&#248;gning
    </p>
    <p>
      \item Enklere tex filer
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item egne kommandoer
    </p>
    <p>
      \item egne milj&#248;er
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item P&#230;nere dokumenter
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="Dont repeat yourself" ID="ID_1957942559" CREATED="1421311672751" MODIFIED="1454664259879">
<node TEXT="Dont repeat yourself" ID="ID_696896386" CREATED="1421311672751" MODIFIED="1454664259881"/>
<node TEXT="Eksempel" ID="ID_1577570031" CREATED="1421311998573" MODIFIED="1454664259884" TEXT_SHORTENED="true"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      {\footnotesize
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
  </body>
</html>
</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
<node TEXT="Eksempel" ID="ID_1304672901" CREATED="1421311998573" MODIFIED="1454664259886" TEXT_SHORTENED="true"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\Line}{\noindent\underline{%
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \hspace{\textwidth}}\vspace{0.25cm}\\}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\Line}{\noindent\underline{%
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \hspace{\textwidth}}\vspace{0.25cm}\\}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
  </body>
</html>
</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
</node>
<node TEXT="Nye kommandoer" ID="ID_1424284378" CREATED="1389706111399" MODIFIED="1454664259888">
<node TEXT="Hvad er en kommando egentlig?" ID="ID_1110338029" CREATED="1418847725197" MODIFIED="1454664259890" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nogle eksempler p&#229; kommandoer
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \tableofcontents
    </p>
    <p>
      
    </p>
    <p>
      \section{Overskrift}
    </p>
    <p>
      
    </p>
    <p>
      \section[Kort overskrift]{En meget lang overskrift
    </p>
    <p>
      der kan fylde flere linjer}
    </p>
    <p>
      
    </p>
    <p>
      \label{figPlotOfFunctions}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer" ID="ID_185352082" CREATED="1418847725197" MODIFIED="1454664259891" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye kommandoer kan oprettes ved hj&#230;lp af \verb!\newcommand!.
    </p>
    <p>
      
    </p>
    <p>
      Eksempel
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand{\sayhello}[1]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Henrik}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Peter}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \hrulefill&#160;
    </p>
    <p>
      
    </p>
    <p>
      \newcommand{\sayhello}[1]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Henrik}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Peter}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Argumenter" ID="ID_1232713107" CREATED="1418847725197" MODIFIED="1454664259893" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Argumenter til kommandoer kan v&#230;re kr&#230;vede eller valgfrie.
    </p>
    <p>
      
    </p>
    <p>
      Eksempel
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand{\sayhelloagain}[1][world]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain{Peter}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \hrulefill&#160;
    </p>
    <p>
      
    </p>
    <p>
      \newcommand{\sayhelloagain}[1][world]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain[Peter]
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer" ID="ID_322904378" CREATED="1418847725197" MODIFIED="1454664259895" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye kommandoer oprettes med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Eksisterende opdateres med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \renewcommand
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer -- specialtilf&#xe6;lde" ID="ID_1251706277" CREATED="1418847725197" MODIFIED="1454664259897" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      En ny kommando kan oprettes hvis den ikke allerede eksisterer med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \providecommand
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      Det sidste kan bruges ved compile time argumenter.
    </p>
    <p>
      {\footnotesize
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      pdflatex '\newcommand{\blackandwhite}{true}\input{test.tex}'
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      }
    </p>
    <p>
      Hvor \texttt{test.tex} indeholder noget i stil med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \providecommand{\blackandwhite}{false}
    </p>
    <p>
      Indhold
    </p>
    <p>
      \blackandwhite
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Nye milj&#xf8;er" ID="ID_559213494" CREATED="1421311631114" MODIFIED="1454664259899">
<node TEXT="Hvad er et milj&#xf8; egentlig?" ID="ID_332130969" CREATED="1418847725197" MODIFIED="1454664259900" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nogle eksempler p&#229; milj&#248;er
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}
    </p>
    <p>
      \includegraphics{...}
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      
    </p>
    <p>
      \begin{tabular}{cc}
    </p>
    <p>
      Hej &amp; Igen \\
    </p>
    <p>
      \end{tabular}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye milj&#xf8;er" ID="ID_247519812" CREATED="1418847725197" MODIFIED="1454664259902" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye milj&#248;er kan oprettes ved hj&#230;lp af \verb!\newenvironment! (\verb!\renewenvironment!)
    </p>
    <p>
      
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newenvironment{receipe}[nargs]{startcode}{endcode}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye milj&#xf8;er 2" ID="ID_419039125" CREATED="1418847725197" MODIFIED="1454664259904" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newenvironment{king}
    </p>
    <p>
      { \rule{1ex}{1ex}\hspace{\stretch{1}} }
    </p>
    <p>
      { \hspace{\stretch{1}}\rule{1ex}{1ex} }
    </p>
    <p>
      
    </p>
    <p>
      \begin{king}
    </p>
    <p>
      My humble subjects \ldots
    </p>
    <p>
      \end{king}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \vfill
    </p>
    <p>
      
    </p>
    <p>
      \newenvironment{king}
    </p>
    <p>
      { \rule{1ex}{1ex}\hspace{\stretch{1}} }
    </p>
    <p>
      { \hspace{\stretch{1}}\rule{1ex}{1ex} }
    </p>
    <p>
      
    </p>
    <p>
      \begin{king}
    </p>
    <p>
      My humble subjects \ldots
    </p>
    <p>
      \end{king}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Referencer" ID="ID_1535930324" CREATED="1421316199836" MODIFIED="1454664259907"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \url{http://en.wikibooks.org/wiki/LaTeX/Macros}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Pakker" ID="ID_604208734" CREATED="1421311643691" MODIFIED="1454664259908">
<node TEXT="Pakker" ID="ID_76627091" CREATED="1421316016454" MODIFIED="1454664259909" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Man kan samle definitioner af nye kommandoer og milj&#248;er i pakker (.sty filer).
    </p>
    <p>
      
    </p>
    <p>
      S&#229; kan de bruges vha. \verb!\usepackage{...}!
    </p>
    <p>
      
    </p>
    <p>
      I en pakke kan man ogs&#229; have andre \verb!\usepackage{...}!
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Fejls&#xf8;gning" ID="ID_1986796368" CREATED="1421328127265" MODIFIED="1454664259911">
<node TEXT="N&#xe5;r skidtet ikke virker \ldots" ID="ID_810872053" CREATED="1421328127265" MODIFIED="1454664259912">
<node TEXT="N&#xe5;r skidtet ikke virker \ldots" ID="ID_15834349" CREATED="1421328127265" MODIFIED="1454664259914"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hvad g&#248;r man n&#229;r \LaTeX{} bare driller?
    </p>
    <p>
      
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Stirrer blindt p&#229; sk&#230;rmen
    </p>
    <p>
      \item Leder systematisk efter fejlen
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Bin&#230;r s&#248;gning
    </p>
    <p>
      \item Minimalt eksempel
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item Sp&#248;rger andre om hj&#230;lp
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item \url{tex.stackexchange.com}
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Bin&#xe6;r s&#xf8;gning efter fejl" ID="ID_1341918802" CREATED="1413106214124" MODIFIED="1454664259915">
<node TEXT="Hvorn&#xe5;r s&#xf8;ge efter fejl?" ID="ID_1141686009" CREATED="1413106214124" MODIFIED="1454664259917" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Mit dokument kompilerer ikke l&#230;ngere \ldots
    </p>
    <p>
      
    </p>
    <p>
      Jeg tror jeg kan rette fejlen selv.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Bin&#xe6;r s&#xf8;gning efter fejl" ID="ID_1327212131" CREATED="1413106214124" MODIFIED="1454664259918" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Udgangspunkt: Dit latex dokument kompilerer ikke \ldots
    </p>
    <p>
      
    </p>
    <p>
      Inds&#230;t \verb!\end{document}! passende steder i dokumentet.
    </p>
    <p>
      
    </p>
    <p>
      \begin{enumerate}
    </p>
    <p>
      \item Lige efter \verb!\begin{document}!
    </p>
    <p>
      \item Midt i dokumentet
    </p>
    <p>
      \item Midt i den del af dokumentet der indeholder fejl
    </p>
    <p>
      \item Midt i den del af dokumentet der indeholder fejl
    </p>
    <p>
      \item \ldots
    </p>
    <p>
      \end{enumerate}
    </p>
    <p>
      
    </p>
    <p>
      Forts&#230;t indtil du ved i hvilken linje problemet ligger.
    </p>
    <p>
      Det tager overraskende kort tid selv i store dokumenter.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Minimal working example" ID="ID_648661342" CREATED="1413106183820" MODIFIED="1454664259919">
<node TEXT="Hvorn&#xe5;r lave et minimalt eksempel?" ID="ID_837777751" CREATED="1421328816036" MODIFIED="1454664259921"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Dokumentet g&#248;r noget som jeg ikke forventer \ldots
    </p>
    <p>
      \item Jeg vil gerne have andres hj&#230;lp
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Form&#229;let ved at lave et minimalt eksempel er at det er lettere for andre at gennemskue hvad der sker (og hvad g&#229;r galt).
    </p>
    <p>
      
    </p>
    <p>
      Det er en stor fordel n&#229;r man stiller sp&#248;rgsm&#229;l online.
    </p>
    <p>
      
    </p>
    <p>
      \begin{block}{Side effekt}
    </p>
    <p>
      Ofte finder man selv fejlen idet man laver et minimalt eksempel\ldots
    </p>
    <p>
      \end{block}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Minimal working example" ID="ID_1587138857" CREATED="1413106183820" MODIFIED="1454664259922"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Fjern ting fra filen der ikke bidrager til problemet.
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      \source{\url{http://www.dickimaw-books.com/latex/minexample/html/hackingdown.html}}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Eksempel start" ID="ID_411808941" CREATED="1421329956857" MODIFIED="1454664663616" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \footnotesize
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \newcommand{\im}{\mathrm{i}}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \newcommand{\e}{\mathrm{e}}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      In the following we want to derive a property \ldots
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      f_N(t) = &amp; \frac{A_0}{2} + \sum_{k=1}^{\infty}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \left( \frac{1}{2} \left( A_k -\im B_k \right)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \e^{} {\im \alpha t} + \frac{1}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \left( A_k + \im B_k \right) \e ^{} {- \im \alpha t} \right) \\
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &amp; \text{mit } B_0=0 \text{ und } \alpha = \omega t
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Problemet er for lille mellemrum mellem = og det efterf&#248;lgende matematik.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel start oversat" ID="ID_1581173055" CREATED="1421329956857" MODIFIED="1454664792846" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \hrule
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \vspace{0.5cm}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \newcommand{\im}{\mathrm{i}}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \newcommand{\e}{\mathrm{e}}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      In the following we want to derive a property \ldots
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      f_N(t) = &amp; \frac{A_0}{2} + \sum_{k=1}^{\infty}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \left( \frac{1}{2} \left( A_k -\im B_k \right)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \e^{} {\im \alpha t} + \frac{1}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \left( A_k + \im B_k \right) \e ^{} {- \im \alpha t} \right) \\
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &amp; \text{mit } B_0=0 \text{ und } \alpha = \omega t
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \hrule
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \vspace{1.0cm}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p>
      Problemet er for lille mellemrum mellem = og det efterf&#248;lgende matematik.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel trin 1" ID="ID_406571002" CREATED="1421329956857" MODIFIED="1454664794824" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      f_N(t) = &amp; \frac{A_0}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel trin 1 oversat" ID="ID_1496487800" CREATED="1421329956857" MODIFIED="1454664805471" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      f_N(t) = &amp; \frac{A_0}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel trin 2" ID="ID_1074154447" CREATED="1421329956857" MODIFIED="1454664826525" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      a = &amp; A
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel trin 2 oversat" ID="ID_1730769445" CREATED="1421329956857" MODIFIED="1454664835727" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      a = &amp; A
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{align}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel slut" ID="ID_1419803926" CREATED="1421329956857" MODIFIED="1454664259927" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; margin-bottom: 0px; margin-right: 0px; text-indent: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \documentclass{article}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      a = &amp; A
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Sp&#xf8;rg p&#xe5; tex.stackexchange.com" ID="ID_1352573991" CREATED="1413106169981" MODIFIED="1454664259928"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      N&#229;r vi har et minimalt eksempel kan vi s&#248;ge hj&#230;lp online, f.eks. p&#229; \url{http://tex.stackexchange.com/}.
    </p>
    <p>
      
    </p>
    <p>
      N&#229;r du stiller sp&#248;rgsm&#229;l s&#229;
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Forklar hvad du gerne vil opn&#229;
    </p>
    <p>
      \item Forklar hvad du har gjort
    </p>
    <p>
      \item Vis det minimale eksempel
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Udseende af latex dokumenter" ID="ID_938666491" CREATED="1412230568552" MODIFIED="1454664259929">
<node TEXT="Pakker" ID="ID_424097942" CREATED="1421696427360" MODIFIED="1454664259930">
<node TEXT="Pakker" ID="ID_1833914682" CREATED="1421696430234" MODIFIED="1454664374420"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Ny funktionalitet i \LaTeX{} stammer fra pakker, der indeholder nye kommandoer og milj&#248;er.
    </p>
    <p>
      \item Pakker ligger som .sty filer der kan hentes ned og installeres p&#229; computeren.
    </p>
    <p>
      \item Vi vil se lidt n&#230;rmere p&#229; de f&#248;lgende pakker
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item fancyhdr
    </p>
    <p>
      \item geometry
    </p>
    <p>
      \item caption
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \end{itemize}
    </p>
    <ul>
      
    </ul>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Dokumentation" ID="ID_1615860457" CREATED="1421696433587" MODIFIED="1454664337535"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Med til pakker h&#248;rer der ofte dokumentation, der beskriver hvordan pakken kan bruges.
    </p>
    <p>
      \item Dokumentationen er generelt af en h&#248;j kvalitet
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Folk &#248;nsker at deres pakker bliver brugt!
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item Informationen kan findes p&#229; \emph{CTAN: Comprehensive TeX Archive Network}
    </p>
    <p>
      \item Eksempel se p&#229; pakken tcolorbox \url{http://www.ctan.org/pkg/tcolorbox}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="Udseende" ID="ID_603615976" CREATED="1421316484260" MODIFIED="1454664259941">
<node TEXT="fancyhdr" ID="ID_1121435263" CREATED="1412230576560" MODIFIED="1454664259941"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Pakken fancyhdr bruges til at ops&#230;tte sidehoved og sidefod.
    </p>
    <p>
      \item \url{http://www.ctan.org/pkg/fancyhdr}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="geometry" ID="ID_654580870" CREATED="1412230582344" MODIFIED="1454664259942" TEXT_SHORTENED="true"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item Pakken geometry benyttes til at definere sideops&#230;tning
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item &#160;&#160;&#160;&#160;sidest&#248;rrelse
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item &#160;&#160;&#160;&#160;margen
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item \url{http://www.ctan.org/pkg/geometry}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
  </body>
</html>

</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
<node TEXT="caption" ID="ID_384034148" CREATED="1412230579440" MODIFIED="1454664259943" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Pakken \emph{caption} benyttes til at definere udseende af figur tekster.
    </p>
    <p>
      \item \url{http://www.ctan.org/pkg/caption}
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Ofte benytte jeg f&#248;lgende parametre n&#229;r pakken indl&#230;ses
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage{caption}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \captionsetup[figure]{labelfont=bf, textfont=it}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \captionsetup[table]{labelfont=bf, textfont=it}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}<br/>
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="placering af figurer" ID="ID_753145231" CREATED="1412667482117" MODIFIED="1454664259943" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      En ting der driller mange i \LaTeX{} er placering af figurer,
    </p>
    <p>
      i den forbindelse er det vigtigt f&#248;rst at f&#229; selve indholdet p&#229; plads og f&#248;rst derefter begynde at justere p&#229; figurers position.
    </p>
    <p>
      
    </p>
    <p>
      F&#248;lgende to virkemidler er hvad jeg benytter
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Angiv placerings&#xf8;nsker til figur milj&#xf8;et" ID="ID_707328907" CREATED="1421697637438" MODIFIED="1454664304362" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}[...]
    </p>
    <p>
      ...
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item h - here
    </p>
    <p>
      \item t - top
    </p>
    <p>
      \item b - bottom
    </p>
    <p>
      \item p - page
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Tving inds&#xe6;ttelse af figurer f&#xf8;r teksten forts&#xe6;ttes" ID="ID_883844051" CREATED="1412667491498" MODIFIED="1454664259947" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Inds&#230;t \verb!\FloatBarrier! for at holde en figur foran en bestemt stump tekst (Kommandoen ligger i placeins pakken)
    </p>
    <p>
      
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}
    </p>
    <p>
      ...
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      
    </p>
    <p>
      \FloatBarrier
    </p>
    <p>
      
    </p>
    <p>
      \section{Overskrift}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Indhold" ID="ID_478253904" CREATED="1421316532444" MODIFIED="1454664259947">
<node TEXT="pdfpages" ID="ID_1247272493" CREATED="1412230599742" MODIFIED="1454664259948"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Benyttes til at inds&#230;tte en eller flere sider fra et andet pdf dokument
    </p>
    <p>
      \item \url{http://www.ctan.org/pkg/pdfpages}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="tikz" ID="ID_118833637" CREATED="1412230601412" MODIFIED="1454664259948"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Kraftigt tegnev&#230;rkt&#248;j
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Figurer med links
    </p>
    <p>
      \item Forsider
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item \url{http://www.ctan.org/pkg/pgf}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="todonotes" ID="ID_859468078" CREATED="1421697383301" MODIFIED="1454664259949"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item \todo{Marker hvad der skal huskes til senere \ldots}
    </p>
    <p>
      \item \missingfigure{Der mangler en figur \ldots}
    </p>
    <p>
      \item \url{http://www.ctan.org/pkg/todonotes}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="matematik" ID="ID_531618249" CREATED="1412797484547" MODIFIED="1454664259950"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item cancel pakken
    </p>
    <p>
      \item farver i formler
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
</node>
<node TEXT="Input fra deltagere" ID="ID_261758376" CREATED="1423650342138" MODIFIED="1424003673965">
<node TEXT="Input fra deltagere" ID="ID_217616233" CREATED="1423644998238" MODIFIED="1424003673968">
<node TEXT="Input 1" ID="ID_686449674" CREATED="1454657804145" MODIFIED="1454664259950">
<node TEXT="Brug af bibtex - og ogs&#xe5; hvis mange kilder." ID="ID_691260758" CREATED="1454656247419" MODIFIED="1454664259951"/>
</node>
<node TEXT="Input 2" ID="ID_590466356" CREATED="1454657807950" MODIFIED="1454664259951">
<node TEXT="Grafiske forsider / avancerede forsider." ID="ID_199030584" CREATED="1454656242469" MODIFIED="1454664259952"/>
</node>
<node TEXT="Input 3" ID="ID_575306294" CREATED="1454657810667" MODIFIED="1454657812054">
<node TEXT="Avanceret ops&#xe6;tning af dokument, padding, margin, skrifttyper mm." ID="ID_159288023" CREATED="1454656233158" MODIFIED="1454656234002"/>
</node>
<node TEXT="Input 4" ID="ID_300744666" CREATED="1454657813359" MODIFIED="1454664259952">
<node TEXT="Brug af latex figur v&#xe6;rkt&#xf8;j, importring af AutoCAD formater, flere forfattere, rotering ved brug af bokse og kort forklaring af usepackage." ID="ID_268837214" CREATED="1454656198281" MODIFIED="1454664259953"/>
</node>
</node>
</node>
<node TEXT="Grafiske forsider" ID="ID_409915619" CREATED="1454656671128" MODIFIED="1454664259954">
<node TEXT="Standard v&#xe6;rkt&#xf8;jer" ID="ID_1629778146" CREATED="1454656679287" MODIFIED="1454664259954">
<node TEXT="Standard v&#xe6;rkt&#xf8;jer" ID="ID_1716798167" CREATED="1423649337482" MODIFIED="1454664259955" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Man kan komme langt med ops&#230;tning af forsider og dokumenter generelt
    </p>
    <p>
      ved at benytte f&#248;lgende kommandoer
    </p>
    <p>
      
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Vertikal luft" ID="ID_420173466" CREATED="1423649337482" MODIFIED="1454664259955" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \vspace{length}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Inds&#230;tter vertikal luft (kan v&#230;re \emph{negativ})
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Standard skriftst&#xf8;rrelser" ID="ID_1405058157" CREATED="1423649337482" MODIFIED="1454664259956" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \tiny
    </p>
    <p>
      \scriptsize
    </p>
    <p>
      \footnotesize
    </p>
    <p>
      \small
    </p>
    <p>
      \normalsize
    </p>
    <p>
      \large
    </p>
    <p>
      \Large
    </p>
    <p>
      \LARGE
    </p>
    <p>
      \huge
    </p>
    <p>
      \Huge
    </p>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Vilk&#xe5;rlige skriftst&#xf8;rrelser" ID="ID_263899645" CREATED="1423649337482" MODIFIED="1454664259956" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      {\fontsize{5cm}{5.5cm}\selectfont This is big!}
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      {\fontsize{5cm}{5.5cm}\selectfont This is big!}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{description}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item[5cm] size
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item[5.5cm] linespace
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{description}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="rule" ID="ID_88220959" CREATED="1423649337482" MODIFIED="1454664259957" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \rule{0.5\textwidth}{.4pt}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \rule{0.5\textwidth}{.4pt}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="thispagestyle" ID="ID_707157732" CREATED="1423649337482" MODIFIED="1454664259957" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \thispagestyle{empty}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      S&#248;rger for at der ikke inds&#230;ttes sidehoved / sidefod p&#229; lige pr&#230;cis denne side.
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="Tikz" ID="ID_984651884" CREATED="1454657650664" MODIFIED="1454664259958">
<node TEXT="Tikz" ID="ID_917319790" CREATED="1454657650664" MODIFIED="1454664259958"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis det skal v&#230;re rigtig avanceret, er tikz det rigtige v&#230;rkt&#248;j
    </p>
    <p>
      
    </p>
    <p>
      Med tikz er det muligt at inds&#230;tte
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item overlappende billeder
    </p>
    <p>
      \item roteret tekst
    </p>
    <p>
      \item linjer, streger, \ldots
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Tikz eksempel" ID="ID_1572497423" CREATED="1454658761904" MODIFIED="1454664259959" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{columns}
    </p>
    <p>
      \begin{column}{0.4\textwidth}
    </p>
    <p>
      \begin{tikzpicture}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%color one half of a unit circle
    </p>
    <p>
      &#160;&#160;\begin{scope}
    </p>
    <p>
      &#160;&#160;&#160;&#160;\clip (0,0) circle (1cm);
    </p>
    <p>
      &#160;&#160;&#160;&#160;\fill[black] (0cm,1cm) rectangle (-1cm, -1cm);
    </p>
    <p>
      &#160;&#160;\end{scope}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%fill heads
    </p>
    <p>
      &#160;&#160;\fill[black] (0,0.5) circle (0.5cm);
    </p>
    <p>
      &#160;&#160;\fill[white] (0,-0.5) circle (0.5cm);
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%fill eyes
    </p>
    <p>
      &#160;&#160;\fill[white] (0,0.5) circle (0.1cm);
    </p>
    <p>
      &#160;&#160;\fill[black] (0,-0.5) circle (0.1cm);
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%outer line
    </p>
    <p>
      &#160;&#160;\draw (0,0) circle (1cm);
    </p>
    <p>
      
    </p>
    <p>
      \end{tikzpicture}
    </p>
    <p>
      \end{column}
    </p>
    <p>
      \begin{column}{0.6\textwidth}
    </p>
    <p>
      \tiny
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{tikzpicture}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%color one half of a unit circle
    </p>
    <p>
      &#160;&#160;\begin{scope}
    </p>
    <p>
      &#160;&#160;&#160;&#160;\clip (0,0) circle (1cm);
    </p>
    <p>
      &#160;&#160;&#160;&#160;\fill[black] (0cm,1cm) rectangle (-1cm, -1cm);
    </p>
    <p>
      &#160;&#160;\end{scope}
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%fill heads
    </p>
    <p>
      &#160;&#160;\fill[black] (0,0.5) circle (0.5cm);
    </p>
    <p>
      &#160;&#160;\fill[white] (0,-0.5) circle (0.5cm);
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%fill eyes
    </p>
    <p>
      &#160;&#160;\fill[white] (0,0.5) circle (0.1cm);
    </p>
    <p>
      &#160;&#160;\fill[black] (0,-0.5) circle (0.1cm);
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;%outer line
    </p>
    <p>
      &#160;&#160;\draw (0,0) circle (1cm);
    </p>
    <p>
      
    </p>
    <p>
      \end{tikzpicture}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      \end{column}
    </p>
    <p>
      \end{columns}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Tikz forside eksempel" ID="ID_775340228" CREATED="1454658761904" MODIFIED="1454664259960" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \scalebox{0.5}{\begin{tikzpicture}[remember picture, overlay]
    </p>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (5, 7)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (7, 8)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[rotate=-22]{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (9, 9)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[rotate=-45]{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw[fill=red, draw=none, opacity = 0.5]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      (current page.south west) ++ (5, 7)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      rectangle ++(4, 3);
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (7, 8.5)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[fill=white, inner sep=0.5cm, anchor=center]{\Huge Titel};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw[-&gt;, very thick] (current page.south west) ++ (11, 4) --
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      ++ (-1, 2);<br/>
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{tikzpicture}
    </p>
    <p>
      }
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Tikz forside kode" ID="ID_1665103693" CREATED="1454658761904" MODIFIED="1454664259960" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \tiny
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{tikzpicture}[remember picture, overlay]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (5, 7)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (7, 8)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[rotate=-22]{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (9, 9)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[rotate=-45]{\includegraphics[width=4cm]{pic/socrativeMCresponse.png}};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw[fill=red, draw=none, opacity = 0.5]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      (current page.south west) ++ (5, 7)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      rectangle ++(4, 3);
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw (current page.south west) ++ (7, 8.5)
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      node[fill=white, inner sep=0.5cm, anchor=center]{\Huge Titel};
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \draw[-&gt;, very thick] (current page.south west) ++ (11, 4) --
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      ++ (-1, 2);<br/>
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{tikzpicture}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
</node>
<node TEXT="Roterede elementer" ID="ID_401473237" CREATED="1454661723683" MODIFIED="1454664259961">
<node TEXT="Roterede elementer" ID="ID_1022382504" CREATED="1454661723683" MODIFIED="1454664259961">
<node TEXT="pakken lscape" ID="ID_746235538" CREATED="1423649337482" MODIFIED="1454664259962" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage{lscape}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      ...
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{landscape}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{figure}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \centering
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \rule{5cm}{2cm}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \caption{En roteret figur.}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{figure}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{landscape}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Sidehoved og sidefod forbliver som de plejer, men den
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      indsatte figur samt den tilh&#248;rende figur tekst bliver roteret 90 grader.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="includegraphics" ID="ID_353246633" CREATED="1423649337482" MODIFIED="1454664259962" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]{pic/socrativeMCresponse.png} 
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width = 3cm, angle=90]{pic/socrativeMCresponse.png} 
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="includegraphics -- kode" ID="ID_1689132636" CREATED="1423649337482" MODIFIED="1454664259963" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Figurere der inds&#230;ttes med \verb!\includegraphics! kommandoen kan roteres med \verb!angle! parameteren.
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width = 3cm, angle=90]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="includegraphics -- r&#xe6;kkef&#xf8;lge af parametre" ID="ID_811620072" CREATED="1423649337482" MODIFIED="1454664259963" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      R&#230;kkef&#248;lgen af parametre til includegraphics er vigtig!
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      % width is set first
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width = 3cm, angle=90]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      % width is set last
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[angle=90, width=3cm]
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="includegraphics -- r&#xe6;kkef&#xf8;lge af parametre" ID="ID_1565593253" CREATED="1423649337482" MODIFIED="1454664259964" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{multicols}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width = 3cm, angle=90]{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[width=3cm]{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \includegraphics[angle=90, width=3cm]{pic/socrativeMCresponse.png}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{multicols}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
</node>
<node TEXT="Store dokumenter" ID="ID_197692643" CREATED="1423649319836" MODIFIED="1454664259964">
<node TEXT="Hoved og underdokumenter" ID="ID_1838387176" CREATED="1423649328450" MODIFIED="1454664259965">
<node TEXT="input" ID="ID_65354617" CREATED="1423649337482" MODIFIED="1454664259965" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \documentclass{book}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \tableofcontents
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter1}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter2}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter3}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Se fuldt eksempel i \emph{eksempler} mappen.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="input" ID="ID_646947528" CREATED="1423649337482" MODIFIED="1454664259966" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Kommandoen \verb!input! inds&#230;tter indholdet af en fil p&#229; kommandoens placering.
    </p>
    <p>
      \item Det er muligt at neste \verb!input! kommandoer.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="include / includeonly" ID="ID_1466323571" CREATED="1423649337482" MODIFIED="1454664259967" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \documentclass{book}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \includeonly{chapter1,chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \begin{document}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \tableofcontents
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter1}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter2}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter3}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Se fuldt eksempel i \emph{eksempler} mappen.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="include / includeonly" ID="ID_739684137" CREATED="1423649337482" MODIFIED="1454664259967" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item
    </p>
    <p>
      Kommandoen \verb!\include{filename.tex}! starter en ny side og inds&#230;tter indholdet af \verb!filename.tex!.
    </p>
    <p>
      \item
    </p>
    <p>
      include kan ikke nestes.
    </p>
    <p>
      \item
    </p>
    <p>
      Kombinationen af \verb!include! og \verb!includeonly! er rigtig praktisk hvis man skal arbejde p&#229; en lille del af et stort dokument.
    </p>
    <p>
      \item
    </p>
    <p>
      \verb!includeonly! beholder indholdsfortegnelsen fra de ikke inkluderede dele af dokumentet.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="subfiles" ID="ID_1490085899" CREATED="1423649334798" MODIFIED="1454664259968"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pakke dokumentation: \url{http://www.ctan.org/pkg/subfiles}
    </p>
    <p>
      
    </p>
    <p>
      Muligg&#248;r opdeling af et hoveddokument i mindre dele, hvor de enkelte dele kan overs&#230;ttes hver for sig.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Versionsstyring" ID="ID_464911078" CREATED="1423649350251" MODIFIED="1454664259968">
<node TEXT="Versionsstyring" ID="ID_1198027799" CREATED="1423650369117" MODIFIED="1454664259969"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      H&#229;ndtere historikken af tekstfiler (og bin&#230;re filer).
    </p>
    <p>
      
    </p>
    <p>
      Velegnede v&#230;rkt&#248;jer inkluderer
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item git / github / bitbucket
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Den lette udgave" ID="ID_1516166047" CREATED="1423650428812" MODIFIED="1454664259969"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Dropbox
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Online latex editorer" ID="ID_1025679996" CREATED="1421760846915" MODIFIED="1454664259970">
<node TEXT="Online latex editorer" ID="ID_244961738" CREATED="1421760841653" MODIFIED="1454664259970"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fordele
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Du er k&#248;rende med det samme
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Ulemper
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Du mister kontrol over dokumentet
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      \url{https://www.overleaf.com/}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Avanceret ops&#xe6;tning af dokumenter" ID="ID_1329607699" CREATED="1454662936960" MODIFIED="1454662945024">
<node TEXT="Padding" ID="ID_862626959" CREATED="1454662945750" MODIFIED="1454662950613"/>
<node TEXT="Margin" ID="ID_1933800119" CREATED="1454662950899" MODIFIED="1454662953174">
<node TEXT="pakken geometry" ID="ID_798664050" CREATED="1423649337482" MODIFIED="1454663347696" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage[top=2.5cm, bottom=4cm,
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      &#160;&#160;left=2cm, right=7cm]{geometry} <br/>
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      L&#230;s mere om pakken her
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item \url{https://en.wikibooks.org/wiki/LaTeX/Page_Layout}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item \url{http://texdoc.net/texmf-dist/doc/latex/geometry/geometry.pdf}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="Skrifttyper" ID="ID_1950061271" CREATED="1454662953408" MODIFIED="1454662955210">
<node TEXT="Skrifttyper - hele dokumenter" ID="ID_27699290" CREATED="1423649337482" MODIFIED="1454664032180" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Der kan v&#230;lges en anden skrifttype for hele dokumentet
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      ved at indl&#230;se en passende pakke.
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage[urw-garamond]{mathdesign}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \usepackage[T1]{fontenc}<br/>
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Se en liste med let tilg&#230;ngelige skrifttyper her
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{itemize}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \item \url{http://www.tug.dk/FontCatalogue/}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Skrifttyper - hele dokumenter" ID="ID_566955470" CREATED="1423649337482" MODIFIED="1454664216213" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      Der kan v&#230;lges en anden skrifttype i en del af dokumentet vha nedenst&#229;ende kode.
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{multicols}{2}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \begin{verbatim}
    </p>
    <p>
      Text in Palatino
    </p>
    <p>
      
    </p>
    <p>
      \bgroup
    </p>
    <p>
      \fontfamily{ptm}
    </p>
    <p>
      \selectfont
    </p>
    <p>
      Text in Times
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \egroup
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{verbatim}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \columnbreak
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p>
      Text in Palatino
    </p>
    <p>
      
    </p>
    <p>
      \bgroup
    </p>
    <p>
      \fontfamily{ptm}
    </p>
    <p>
      \selectfont
    </p>
    <p>
      Text in Times
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \egroup
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \end{multicols}
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      
    </p>
    <p style="margin-left: 0px; margin-top: 0px; text-indent: 0px; margin-bottom: 0px; margin-right: 0px">
      \source{\url{http://tex.stackexchange.com/a/2054/1366}}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
</node>
<node TEXT="Latex og eksterne v&#xe6;rkt&#xf8;jer" ID="ID_552287944" CREATED="1412230615220" MODIFIED="1454664259971">
<node TEXT="Biblatex" ID="ID_234781421" CREATED="1423648153204" MODIFIED="1454664259971">
<node TEXT="Biblatex" ID="ID_290157909" CREATED="1423648407010" MODIFIED="1454664259972"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Biblatex er den moderne udgave af bibtex.
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item lettere at bruge
    </p>
    <p>
      \item flere features
    </p>
    <p>
      \item \ldots
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex eksempel" ID="ID_252991048" CREATED="1423648550258" MODIFIED="1454664259972" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-right: 0px; text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px">
      \documentclass{article}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[utf8]{inputenc}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[danish]{babel}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[backend=biber,
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      &#160;&#160;style=authoryear, natbib=true]{biblatex}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \addbibresource{references.bib}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      <br/>
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \begin{document}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Du kan citere artikler \citep{Ahmad1998}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Ogs&#229; p&#229; tekstform, \citet{Andersen2000}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Sidenumre kan medtages \citep[s. 19]{Alchanatis2001}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      <br/>
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \printbibliography
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex brugsm&#xf8;nster" ID="ID_1156929164" CREATED="1423648550258" MODIFIED="1454664259973" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Dokumenter der bruger biblatex (med biber som backend) skal overs&#230;ttes p&#229; f&#248;lgende m&#229;de
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item biber
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Benyttes bibtex som backend, er proceduren
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item bibtex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Bibtex vs. biber" ID="ID_982365190" CREATED="1423648388676" MODIFIED="1454664259973"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Bibtex er et gammelt program fra 1980'erne, som bl.a. kan have problemer med store reference databaser og h&#229;ndterer special tegn d&#229;rligt.
    </p>
    <p>
      \item Biber er en ny opdatering / genskrivning af bibtex, som ikke har disse problemer.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex -- ressourcer" ID="ID_1170763852" CREATED="1423648161203" MODIFIED="1454664259974"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item ShareLatex -- Getting Started with Biblatex \\
    </p>
    <p>
      \url{https://www.sharelatex.com/blog/2013/07/31/getting-started-with-biblatex.html}
    </p>
    <p>
      \item Biblatex dokumentation (advarsel $\sim$ 250 sider) \\
    </p>
    <p>
      \url{http://mirror.ox.ac.uk/sites/ctan.org/macros/latex/contrib/biblatex/doc/biblatex.pdf}
    </p>
    <p>
      \item Eksempel p&#229; brug af biblatex (fra tex.stackexchange.com) \\
    </p>
    <p>
      \url{http://tex.stackexchange.com/a/34136/1366}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="H&#xe5;ndtering af referencer" ID="ID_908885201" CREATED="1412230623481" MODIFIED="1454664259974">
<node TEXT="H&#xe5;ndtering af referencer" ID="ID_186270263" CREATED="1412230623481" MODIFIED="1454664260045"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Programmer til at h&#229;ndtere en artikeldatabase
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item jabref
    </p>
    <p>
      \item mendeley, demonstrationsvideo \url{https://www.youtube.com/watch?v=ubv1hwN7vvw}
    </p>
    <p>
      \item zotero
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Fra excel til latex tabeller" ID="ID_1998225009" CREATED="1423649449283" MODIFIED="1454664260045">
<node TEXT="Online v&#xe6;rkt&#xf8;jer" ID="ID_1826409784" CREATED="1423649461457" MODIFIED="1454664260045"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item \url{http://ericwood.org/excel2latex/} \\
    </p>
    <p>
      Kan udtr&#230;kke tekst fra .xlsx filer og formattere det som latex tabeller.
    </p>
    <p>
      \item \url{http://www.tablesgenerator.com/} \\
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="L&#xf8;se ender" ID="ID_412841517" CREATED="1421327747419" MODIFIED="1454664260046">
<node TEXT="L&#xf8;se ender" ID="ID_993257159" CREATED="1421327747419" MODIFIED="1454664260046">
<node TEXT="L&#xf8;se ender" ID="ID_179467560" CREATED="1421327747419" MODIFIED="1454664260046">
<node TEXT="hyphenation" ID="ID_997386406" CREATED="1421327752359" MODIFIED="1454664260047"/>
</node>
<node TEXT="Skriv matematik i latex" ID="ID_884758890" CREATED="1421915312705" MODIFIED="1454664260047">
<node TEXT="\url{http://en.wikibooks.org/wiki/LaTeX/Mathematics}" ID="ID_1491762892" CREATED="1421915317169" MODIFIED="1454664260047"/>
</node>
<node TEXT="Latex vs. word" ID="ID_1804863539" CREATED="1422518102085" MODIFIED="1454664260048"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      An Efficiency Comparison of Document Preparation Systems Used in Academic Research and Development,
    </p>
    <p>
      Markus Knauff og Jelica Nejasmic
    </p>
    <p>
      
    </p>
    <p>
      \url{http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0115069}
    </p>
    <p>
      
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Indskrive tre eksempler, hver inden for 30 min
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Tekst
    </p>
    <p>
      \item Tabeller
    </p>
    <p>
      \item Matematik
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item F&#230;rre fejl i matematik
    </p>
    <p>
      \item Flere fejl i tabeller og tekst
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="index" ID="ID_151713987" CREATED="1412230650235" MODIFIED="1454664260048">
<node TEXT="index" ID="ID_1036105064" CREATED="1412230650235" MODIFIED="1454664260048"/>
</node>
<node TEXT="T&#xe6;llere i latex" ID="ID_775443696" CREATED="1448960876607" MODIFIED="1454664260049">
<node TEXT="\url{https://en.wikibooks.org/wiki/LaTeX/Counters}" ID="ID_1223340111" CREATED="1448960890287" MODIFIED="1454664260049"/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
