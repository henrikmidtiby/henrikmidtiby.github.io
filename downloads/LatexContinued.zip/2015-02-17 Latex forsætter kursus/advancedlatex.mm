<map version="freeplane 1.3.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Latex kurser" ID="ID_1723255651" CREATED="1283093380553" MODIFIED="1422260548654"><hook NAME="MapStyle">
    <properties show_icon_for_attributes="true" show_note_icons="true"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node">
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right">
<stylenode LOCALIZED_TEXT="default" COLOR="#000000" STYLE="fork" MAX_WIDTH="600">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.note"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
<font SIZE="10"/>
</stylenode>
</stylenode>
</stylenode>
</map_styles>
</hook>
<attribute NAME="theme" VALUE="Goettingen"/>
<attribute NAME="usepackage" VALUE="hsmpresentation"/>
<font ITALIC="true"/>
<node TEXT="\LaTeX - forts&#xe6;tterkursus" POSITION="right" ID="ID_1478305903" CREATED="1418549464650" MODIFIED="1421697560954" TEXT_SHORTENED="true">
<attribute NAME="author" VALUE="Henrik Skov Midtiby"/>
<attribute NAME="date" VALUE="2015-02-11 "/>
<node TEXT="Tilpasning af \LaTeX" ID="ID_1944298718" CREATED="1418652535878" MODIFIED="1424002548647">
<node TEXT="M&#xe5;let med i aften" ID="ID_1462463948" CREATED="1421325969122" MODIFIED="1424002548651">
<node TEXT="M&#xe5;let med i aften" ID="ID_1820951604" CREATED="1421325998011" MODIFIED="1424002548652">
<node TEXT="Mindre b&#xf8;vl med latex dokumenter" ID="ID_1923670882" CREATED="1421325973372" MODIFIED="1424002548654"/>
<node TEXT="Bedre fejls&#xf8;gning" ID="ID_177045644" CREATED="1421325991793" MODIFIED="1424002548655"/>
<node TEXT="Enklere tex filer" ID="ID_1607756550" CREATED="1421326007645" MODIFIED="1424002548656">
<node TEXT="egne kommandoer" ID="ID_170155866" CREATED="1421326018739" MODIFIED="1424002548657"/>
<node TEXT="egne milj&#xf8;er" ID="ID_867701220" CREATED="1421326029515" MODIFIED="1424002548659"/>
</node>
<node TEXT="P&#xe6;nere dokumenter" ID="ID_1414338762" CREATED="1421326054513" MODIFIED="1424002548660"/>
</node>
</node>
<node TEXT="Dont repeat yourself" ID="ID_1957942559" CREATED="1421311672751" MODIFIED="1424003120860">
<icon BUILTIN="button_ok"/>
<node TEXT="Dont repeat yourself" ID="ID_696896386" CREATED="1421311672751" MODIFIED="1424003120862">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Eksempel" ID="ID_1577570031" CREATED="1421311998573" MODIFIED="1424003120862" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      {\footnotesize
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      }
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
    <p>
      \noindent\underline{\hspace{\textwidth}}\vspace{0.25cm}\\
    </p>
  </body>
</html>

</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
<node TEXT="Eksempel" ID="ID_1304672901" CREATED="1421311998573" MODIFIED="1424003120863" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\Line}{\noindent\underline{%
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \hspace{\textwidth}}\vspace{0.25cm}\\}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\Line}{\noindent\underline{%
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \hspace{\textwidth}}\vspace{0.25cm}\\}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      <br/>
      
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \Line
    </p>
  </body>
</html>

</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
</node>
<node TEXT="Nye kommandoer" ID="ID_1424284378" CREATED="1389706111399" MODIFIED="1424003275064">
<icon BUILTIN="button_ok"/>
<node TEXT="Hvad er en kommando egentlig?" ID="ID_1110338029" CREATED="1418847725197" MODIFIED="1424003275066" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nogle eksempler p&#229; kommandoer
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \tableofcontents
    </p>
    <p>
      
    </p>
    <p>
      \section{Overskrift}
    </p>
    <p>
      
    </p>
    <p>
      \section[Kort overskrift]{En meget lang overskrift
    </p>
    <p>
      der kan fylde flere linjer}
    </p>
    <p>
      
    </p>
    <p>
      \label{figPlotOfFunctions}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer" ID="ID_185352082" CREATED="1418847725197" MODIFIED="1424003275066" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye kommandoer kan oprettes ved hj&#230;lp af \verb!\newcommand!.
    </p>
    <p>
      
    </p>
    <p>
      Eksempel
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand{\sayhello}[1]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Henrik}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Peter}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \hrulefill&#160;
    </p>
    <p>
      
    </p>
    <p>
      \newcommand{\sayhello}[1]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Henrik}
    </p>
    <p>
      
    </p>
    <p>
      \sayhello{Peter}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Argumenter" ID="ID_1232713107" CREATED="1418847725197" MODIFIED="1424003275067" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Argumenter til kommandoer kan v&#230;re kr&#230;vede eller valgfrie.
    </p>
    <p>
      
    </p>
    <p>
      Eksempel
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand{\sayhelloagain}[1][world]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain{Peter}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \hrulefill&#160;
    </p>
    <p>
      
    </p>
    <p>
      \newcommand{\sayhelloagain}[1][world]{Hello #1!}
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain
    </p>
    <p>
      
    </p>
    <p>
      \sayhelloagain[Peter]
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer" ID="ID_322904378" CREATED="1418847725197" MODIFIED="1424003275067" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye kommandoer oprettes med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newcommand
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Eksisterende opdateres med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \renewcommand
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye kommandoer -- specialtilf&#xe6;lde" ID="ID_1251706277" CREATED="1418847725197" MODIFIED="1424003275068" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      En ny kommando kan oprettes hvis den ikke allerede eksisterer med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \providecommand
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      Det sidste kan bruges ved compile time argumenter.
    </p>
    <p>
      {\footnotesize
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      pdflatex '\newcommand{\blackandwhite}{true}\input{test.tex}'
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      }
    </p>
    <p>
      Hvor \texttt{test.tex} indeholder noget i stil med
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \providecommand{\blackandwhite}{false}
    </p>
    <p>
      Indhold
    </p>
    <p>
      \blackandwhite
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Nye milj&#xf8;er" ID="ID_559213494" CREATED="1421311631114" MODIFIED="1424003277481">
<icon BUILTIN="button_ok"/>
<node TEXT="Hvad er et milj&#xf8; egentlig?" ID="ID_332130969" CREATED="1418847725197" MODIFIED="1424003277485" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nogle eksempler p&#229; milj&#248;er
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}
    </p>
    <p>
      \includegraphics{...}
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      
    </p>
    <p>
      \begin{tabular}{cc}
    </p>
    <p>
      Hej &amp; Igen \\
    </p>
    <p>
      \end{tabular}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye milj&#xf8;er" ID="ID_247519812" CREATED="1418847725197" MODIFIED="1424003277486" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Nye milj&#248;er kan oprettes ved hj&#230;lp af \verb!\newenvironment! (\verb!\renewenvironment!)
    </p>
    <p>
      
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newenvironment{receipe}[nargs]{startcode}{endcode}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Nye milj&#xf8;er 2" ID="ID_419039125" CREATED="1418847725197" MODIFIED="1424003277486" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \newenvironment{king}
    </p>
    <p>
      { \rule{1ex}{1ex}\hspace{\stretch{1}} }
    </p>
    <p>
      { \hspace{\stretch{1}}\rule{1ex}{1ex} }
    </p>
    <p>
      
    </p>
    <p>
      \begin{king}
    </p>
    <p>
      My humble subjects \ldots
    </p>
    <p>
      \end{king}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      \vfill
    </p>
    <p>
      
    </p>
    <p>
      \newenvironment{king}
    </p>
    <p>
      { \rule{1ex}{1ex}\hspace{\stretch{1}} }
    </p>
    <p>
      { \hspace{\stretch{1}}\rule{1ex}{1ex} }
    </p>
    <p>
      
    </p>
    <p>
      \begin{king}
    </p>
    <p>
      My humble subjects \ldots
    </p>
    <p>
      \end{king}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Referencer" ID="ID_1535930324" CREATED="1421316199836" MODIFIED="1424003277487">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \url{http://en.wikibooks.org/wiki/LaTeX/Macros}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Pakker" ID="ID_604208734" CREATED="1421311643691" MODIFIED="1424002548665">
<node TEXT="Pakker" ID="ID_76627091" CREATED="1421316016454" MODIFIED="1424002554539" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Man kan samle definitioner af nye kommandoer og milj&#248;er i pakker (.sty filer).
    </p>
    <p>
      
    </p>
    <p>
      S&#229; kan de bruges vha. \verb!\usepackage{...}!
    </p>
    <p>
      
    </p>
    <p>
      I en pakke kan man ogs&#229; have andre \verb!\usepackage{...}!
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Fejls&#xf8;gning" ID="ID_1986796368" CREATED="1421328127265" MODIFIED="1424002878423">
<icon BUILTIN="button_ok"/>
<node TEXT="N&#xe5;r skidtet ikke virker \ldots" ID="ID_810872053" CREATED="1421328127265" MODIFIED="1424002878425">
<icon BUILTIN="button_ok"/>
<node TEXT="N&#xe5;r skidtet ikke virker \ldots" ID="ID_15834349" CREATED="1421328127265" MODIFIED="1424002878426">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hvad g&#248;r man n&#229;r \LaTeX{} bare driller?
    </p>
    <p>
      
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Stirrer blindt p&#229; sk&#230;rmen
    </p>
    <p>
      \item Leder systematisk efter fejlen
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Bin&#230;r s&#248;gning
    </p>
    <p>
      \item Minimalt eksempel
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item Sp&#248;rger andre om hj&#230;lp
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item \url{tex.stackexchange.com}
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Bin&#xe6;r s&#xf8;gning efter fejl" ID="ID_1341918802" CREATED="1413106214124" MODIFIED="1424002878426">
<icon BUILTIN="button_ok"/>
<node TEXT="Hvorn&#xe5;r s&#xf8;ge efter fejl?" ID="ID_1141686009" CREATED="1413106214124" MODIFIED="1424002878426" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Mit dokument kompilerer ikke l&#230;ngere \ldots
    </p>
    <p>
      
    </p>
    <p>
      Jeg tror jeg kan rette fejlen selv.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Bin&#xe6;r s&#xf8;gning efter fejl" ID="ID_1327212131" CREATED="1413106214124" MODIFIED="1424002878427" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Udgangspunkt: Dit latex dokument kompilerer ikke \ldots
    </p>
    <p>
      
    </p>
    <p>
      Inds&#230;t \verb!\end{document}! passende steder i dokumentet.
    </p>
    <p>
      
    </p>
    <p>
      \begin{enumerate}
    </p>
    <p>
      \item Lige efter \verb!\begin{document}!
    </p>
    <p>
      \item Midt i dokumentet
    </p>
    <p>
      \item Midt i den del af dokumentet der indeholder fejl
    </p>
    <p>
      \item Midt i den del af dokumentet der indeholder fejl
    </p>
    <p>
      \item \ldots
    </p>
    <p>
      \end{enumerate}
    </p>
    <p>
      
    </p>
    <p>
      Forts&#230;t indtil du ved i hvilken linje problemet ligger.
    </p>
    <p>
      Det tager overraskende kort tid selv i store dokumenter.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Minimal working example" ID="ID_648661342" CREATED="1413106183820" MODIFIED="1424002878427">
<icon BUILTIN="button_ok"/>
<node TEXT="Hvorn&#xe5;r lave et minimalt eksempel?" ID="ID_837777751" CREATED="1421328816036" MODIFIED="1424002878428">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hvis
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Dokumentet g&#248;r noget som jeg ikke forventer \ldots
    </p>
    <p>
      \item Jeg vil gerne have andres hj&#230;lp
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Form&#229;let ved at lave et minimalt eksempel er at det er lettere for andre at gennemskue hvad der sker (og hvad g&#229;r galt).
    </p>
    <p>
      
    </p>
    <p>
      Det er en stor fordel n&#229;r man stiller sp&#248;rgsm&#229;l online.
    </p>
    <p>
      
    </p>
    <p>
      \begin{block}{Side effekt}
    </p>
    <p>
      Ofte finder man selv fejlen idet man laver et minimalt eksempel\ldots
    </p>
    <p>
      \end{block}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Minimal working example" ID="ID_1587138857" CREATED="1413106183820" MODIFIED="1424002878428">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Fjern ting fra filen der ikke bidrager til problemet.
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      \source{\url{http://www.dickimaw-books.com/latex/minexample/html/hackingdown.html}}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Eksempel start" ID="ID_411808941" CREATED="1421329956857" MODIFIED="1424003552707" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \footnotesize
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \usepackage{amsmath}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\im}{\mathrm{i}}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \newcommand{\e}{\mathrm{e}}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      In the following we want to derive a property \ldots
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \begin{align}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      f_N(t) = &amp; \frac{A_0}{2} + \sum_{k=1}^{}\infty
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \left( \frac{1}{2} \left( A_k -\im B_k \right)
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \e^{} {\im \alpha t} + \frac{1}{2}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \left( A_k + \im B_k \right) \e ^{} {- \im alpha t} \right) \\
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      &amp; \text{mit } B_0=0 \text{ und } \alpha = \omega t
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \end{align}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Problemet er for lille mellemrum mellem = og det efterf&#248;lgende matematik.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="Eksempel trin 1" ID="ID_406571002" CREATED="1421329956857" MODIFIED="1424002878429" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; margin-bottom: 0px; margin-right: 0px; text-indent: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      f_N(t) = &amp; \frac{A_0}{2}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Eksempel trin 2" ID="ID_1074154447" CREATED="1421329956857" MODIFIED="1424002878429" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; margin-bottom: 0px; margin-right: 0px; text-indent: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \documentclass[a4paper]{article}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      a = &amp; A
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Eksempel slut" ID="ID_1419803926" CREATED="1421329956857" MODIFIED="1424002878430" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-left: 0px; margin-bottom: 0px; margin-right: 0px; text-indent: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \documentclass{article}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \usepackage{amsmath}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \begin{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      a = &amp; A
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{align}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{document}
    </p>
    <p style="margin-top: 0px; margin-left: 0px; margin-right: 0px; margin-bottom: 0px; text-indent: 0px">
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Sp&#xf8;rg p&#xe5; tex.stackexchange.com" ID="ID_1352573991" CREATED="1413106169981" MODIFIED="1424002878430">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      N&#229;r vi har et minimalt eksempel kan vi s&#248;ge hj&#230;lp online, f.eks. p&#229; \url{http://tex.stackexchange.com/}.
    </p>
    <p>
      
    </p>
    <p>
      N&#229;r du stiller sp&#248;rgsm&#229;l s&#229;
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Forklar hvad du gerne vil opn&#229;
    </p>
    <p>
      \item Forklar hvad du har gjort
    </p>
    <p>
      \item Vis det minimale eksempel
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Udseende af latex dokumenter" ID="ID_938666491" CREATED="1412230568552" MODIFIED="1424002884137">
<icon BUILTIN="button_ok"/>
<node TEXT="Pakker" ID="ID_424097942" CREATED="1421696427360" MODIFIED="1424002884139">
<icon BUILTIN="button_ok"/>
<node TEXT="Pakker" ID="ID_1833914682" CREATED="1421696430234" MODIFIED="1424002884140">
<icon BUILTIN="button_ok"/>
<node TEXT="Ny funktionalitet i \LaTeX{} stammer fra pakker, der indeholder nye kommandoer og milj&#xf8;er." ID="ID_1714714541" CREATED="1421696611374" MODIFIED="1424002884140">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Pakker ligger som .sty filer der kan hentes ned og installeres p&#xe5; computeren." ID="ID_533960786" CREATED="1421696611374" MODIFIED="1424002884141">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Vi vil se lidt n&#xe6;rmere p&#xe5; de f&#xf8;lgende pakker" ID="ID_1260306852" CREATED="1421696611376" MODIFIED="1424002884141">
<icon BUILTIN="button_ok"/>
<node TEXT="fancyhdr" ID="ID_926489166" CREATED="1421696532747" MODIFIED="1424002884142">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="geometry" ID="ID_1210786975" CREATED="1421696535598" MODIFIED="1424002884142">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="caption" ID="ID_1258299799" CREATED="1421696537464" MODIFIED="1424002884142">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node TEXT="Dokumentation" ID="ID_1615860457" CREATED="1421696433587" MODIFIED="1424002884143">
<icon BUILTIN="button_ok"/>
<node TEXT="Med til pakker h&#xf8;rer der ofte dokumentation, der beskriver hvordan pakken kan bruges." ID="ID_53267694" CREATED="1421696643409" MODIFIED="1424002884143">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Dokumentationen er generelt af en h&#xf8;j kvalitet" ID="ID_530431888" CREATED="1421697047561" MODIFIED="1424002884144">
<icon BUILTIN="button_ok"/>
<node TEXT="Folk &#xf8;nsker at deres pakker bliver brugt!" ID="ID_1544244737" CREATED="1421697094073" MODIFIED="1424002884144">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="Informationen kan findes p&#xe5; \emph{CTAN: Comprehensive TeX Archive Network}" ID="ID_1831784394" CREATED="1421696643409" MODIFIED="1424002884145">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="Eksempel se p&#xe5; pakken tcolorbox \url{http://www.ctan.org/pkg/tcolorbox}" ID="ID_909243382" CREATED="1421696778840" MODIFIED="1424002884145">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node TEXT="Udseende" ID="ID_603615976" CREATED="1421316484260" MODIFIED="1424002884146">
<icon BUILTIN="button_ok"/>
<node TEXT="fancyhdr" ID="ID_1121435263" CREATED="1412230576560" MODIFIED="1424002884146">
<icon BUILTIN="button_ok"/>
<node TEXT="Pakken fancyhdr bruges til at ops&#xe6;tte sidehoved og sidefod." ID="ID_168312286" CREATED="1421697115568" MODIFIED="1424002884147">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="\url{http://www.ctan.org/pkg/fancyhdr}" ID="ID_582462959" CREATED="1421697209343" MODIFIED="1424002884147">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="geometry" ID="ID_654580870" CREATED="1412230582344" MODIFIED="1424002884148" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \begin{itemize}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \item Pakken geometry benyttes til at definere sideops&#230;tning
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \begin{itemize}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \item &#160;&#160;&#160;&#160;sidest&#248;rrelse
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \item &#160;&#160;&#160;&#160;margen
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \end{itemize}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \item \url{http://www.ctan.org/pkg/geometry}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \end{itemize}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \begin{verbatim}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \usepackage{caption}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \captionsetup[figure]{labelfont=bf, textfont=it}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \captionsetup[table]{labelfont=bf, textfont=it}
    </p>
    <p style="margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; text-indent: 0px">
      \end{verbatim}<br/>
    </p>
  </body>
</html>
</richcontent>
<attribute NAME="options" VALUE="fragile"/>
</node>
<node TEXT="caption" ID="ID_384034148" CREATED="1412230579440" MODIFIED="1424002884148" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<node TEXT="Pakken caption benyttes til at definere udseende af figur tekster." ID="ID_10229198" CREATED="1421697157759" MODIFIED="1424002884149">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="\url{http://www.ctan.org/pkg/caption}" ID="ID_1153791933" CREATED="1421697233573" MODIFIED="1424002884149">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="placering af figurer" ID="ID_753145231" CREATED="1412667482117" MODIFIED="1424002884150" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      En ting der driller mange i \LaTeX{} er placering af figurer,
    </p>
    <p>
      i den forbindelse er det vigtigt f&#248;rst at f&#229; selve indholdet p&#229; plads og f&#248;rst derefter begynde at justere p&#229; figurers position.
    </p>
    <p>
      
    </p>
    <p>
      F&#248;lgende to virkemidler er hvad jeg benytter
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Angiv placerings&#xf8;nsker til figur milj&#xf8;et" ID="ID_707328907" CREATED="1421697637438" MODIFIED="1424002884150" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}[...]
    </p>
    <p>
      ...
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
<node TEXT="h - here" ID="ID_1414050411" CREATED="1421697659873" MODIFIED="1424002884150">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="t - top" ID="ID_1661054622" CREATED="1421697662805" MODIFIED="1424002884151">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="b - bottom" ID="ID_321530351" CREATED="1421697665448" MODIFIED="1424002884151">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="p - page" ID="ID_1280349575" CREATED="1421697669571" MODIFIED="1424002884152">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="Tving inds&#xe6;ttelse af figurer f&#xf8;r teksten forts&#xe6;ttes" ID="ID_883844051" CREATED="1412667491498" MODIFIED="1424002884152" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Inds&#230;t \verb!\FloatBarrier! for at holde en figur foran en bestemt stump tekst (Kommandoen ligger i placeins pakken)
    </p>
    <p>
      
    </p>
    <p>
      \begin{verbatim}
    </p>
    <p>
      \begin{figure}
    </p>
    <p>
      ...
    </p>
    <p>
      \end{figure}
    </p>
    <p>
      
    </p>
    <p>
      \FloatBarrier
    </p>
    <p>
      
    </p>
    <p>
      \section{Overskrift}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Indhold" ID="ID_478253904" CREATED="1421316532444" MODIFIED="1424002884153">
<icon BUILTIN="button_ok"/>
<node TEXT="pdfpages" ID="ID_1247272493" CREATED="1412230599742" MODIFIED="1424002884153">
<icon BUILTIN="button_ok"/>
<node TEXT="Benyttes til at inds&#xe6;tte en eller flere sider fra et andet pdf dokument" ID="ID_1619409909" CREATED="1421698057319" MODIFIED="1424002884154">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="\url{http://www.ctan.org/pkg/pdfpages}" ID="ID_1615157206" CREATED="1421697209343" MODIFIED="1424002884154">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="tikz" ID="ID_118833637" CREATED="1412230601412" MODIFIED="1424002884155">
<icon BUILTIN="button_ok"/>
<node TEXT="Kraftigt tegnev&#xe6;rkt&#xf8;j" ID="ID_1340218514" CREATED="1421698113923" MODIFIED="1424002884155">
<icon BUILTIN="button_ok"/>
<node TEXT="Figurer med links" ID="ID_625882012" CREATED="1412230607211" MODIFIED="1424002884155">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="\url{http://www.ctan.org/pkg/pgf}" ID="ID_304541841" CREATED="1421697209343" MODIFIED="1424002884156">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="todonotes" ID="ID_859468078" CREATED="1421697383301" MODIFIED="1424002884156">
<icon BUILTIN="button_ok"/>
<node TEXT="\todo{Marker hvad der skal huskes til senere \ldots}" ID="ID_1803819194" CREATED="1421698168100" MODIFIED="1424002884157">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="\missingfigure{Der mangler en figur \ldots}" ID="ID_987506476" CREATED="1421698368343" MODIFIED="1424002884157">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="\url{http://www.ctan.org/pkg/todonotes}" ID="ID_5627153" CREATED="1421697209343" MODIFIED="1424002884158">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="matematik" ID="ID_531618249" CREATED="1412797484547" MODIFIED="1424002884158">
<icon BUILTIN="button_ok"/>
<node TEXT="cancel pakken" ID="ID_939851098" CREATED="1412797489117" MODIFIED="1424002884159">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="farver i formler" ID="ID_194989249" CREATED="1412797493118" MODIFIED="1424002884160">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
<node TEXT="Input fra deltagere" ID="ID_261758376" CREATED="1423650342138" MODIFIED="1424003673965">
<node TEXT="Input fra deltagere" ID="ID_217616233" CREATED="1423644998238" MODIFIED="1424003673968">
<node TEXT="windows / linux" ID="ID_605510965" CREATED="1423645025668" MODIFIED="1424003673969"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Et alternativ til Miktex, som kan k&#248;rer i linux for at det er muligt at skrive dokumenter i begge systemer
    </p>
    <p>
      Det er i forbindelse med skole, da skal vi arbejde med b&#229;de windows og linux s&#229; det kunne v&#230;re rart
    </p>
    <p>
      hvis det kunne lade sig g&#248;re at arbejde p&#229; tv&#230;rs af systemerne.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="nye kommandoer / modificere eksisterende kommandoer / bibtex" ID="ID_1307391471" CREATED="1423645057481" MODIFIED="1424003673970"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Jeg vil gerne g&#229; lidt i dybden med at programmere nye kommandoer eller modificere kommandoer
    </p>
    <p>
      fra indl&#230;ste pakker. Derudover vil jeg gerne arbejde med Bibtex.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Excel til latex" ID="ID_807918498" CREATED="1423645083658" MODIFIED="1424003673971"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Inport at data fra Excel til LaTex, hvordan f&#229;r man nemt en p&#230;n tabel ud af det?
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Referencer" ID="ID_475907896" CREATED="1423645095947" MODIFIED="1424003673971"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Referencebibliotek og generelt hvordan referencer g&#248;res smart.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Skabeloner" ID="ID_147627098" CREATED="1423645112314" MODIFIED="1424003673972"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      En skabelon som alle dokumenter kan tr&#230;kke p&#229; s&#229; det ikke er n&#248;dvendigt at skrive alle
    </p>
    <p>
      userpackage igen og igen, hvis det er muligt.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Hoved dokument / under dokumenter" ID="ID_927707815" CREATED="1423645126252" MODIFIED="1424003673973"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Hoved dokument vs. Underdokumenter: Hvordan man laver et masterdokument og har mindre
    </p>
    <p>
      underdokumenter som inkluderes.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Versionskontrol" ID="ID_330084938" CREATED="1423645145161" MODIFIED="1424003673974"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Versionskontrol til gruppearbejde, fx github eller SVN.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Store dokumenter" ID="ID_197692643" CREATED="1423649319836" MODIFIED="1424003670012">
<node TEXT="Hoved og underdokumenter" ID="ID_1838387176" CREATED="1423649328450" MODIFIED="1424003670017">
<node TEXT="input" ID="ID_65354617" CREATED="1423649337482" MODIFIED="1424004579490" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \documentclass{book}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \begin{document}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \tableofcontents
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter1}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter2}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter3}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \input{chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px; margin-right: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Se fuldt eksempel i \emph{eksempler} mappen.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="input" ID="ID_646947528" CREATED="1423649337482" MODIFIED="1424004674527" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Kommandoen \verb!input! inds&#230;tter indholdet af en fil p&#229; kommandoens placering.
    </p>
    <p>
      \item Det er muligt at neste \verb!input! kommandoer.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="include / includeonly" ID="ID_1466323571" CREATED="1423649337482" MODIFIED="1424004597933" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \documentclass{book}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \includeonly{chapter1,chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \begin{document}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \tableofcontents
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter1}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter2}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter3}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \include{chapter4}
    </p>
    <p style="text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; margin-top: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
    <p>
      
    </p>
    <p>
      Se fuldt eksempel i \emph{eksempler} mappen.
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="include / includeonly" ID="ID_739684137" CREATED="1423649337482" MODIFIED="1424004655689" TEXT_SHORTENED="true">
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item
    </p>
    <p>
      Kommandoen \verb!\include{filename.tex}! starter en ny side og inds&#230;tter indholdet af \verb!filename.tex!.
    </p>
    <p>
      \item
    </p>
    <p>
      include kan ikke nestes.
    </p>
    <p>
      \item
    </p>
    <p>
      Kombinationen af \verb!include! og \verb!includeonly! er rigtig praktisk hvis man skal arbejde p&#229; en lille del af et stort dokument.
    </p>
    <p>
      \item
    </p>
    <p>
      \verb!includeonly! beholder indholdsfortegnelsen fra de ikke inkluderede dele af dokumentet.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="subfiles" ID="ID_1490085899" CREATED="1423649334798" MODIFIED="1424003670020"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pakke dokumentation: \url{http://www.ctan.org/pkg/subfiles}
    </p>
    <p>
      
    </p>
    <p>
      Muligg&#248;r opdeling af et hoveddokument i mindre dele, hvor de enkelte dele kan overs&#230;ttes hver for sig.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Versionsstyring" ID="ID_464911078" CREATED="1423649350251" MODIFIED="1424003670021">
<node TEXT="Versionsstyring" ID="ID_1198027799" CREATED="1423650369117" MODIFIED="1424003670022"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      H&#229;ndtere historikken af tekstfiler (og bin&#230;re filer).
    </p>
    <p>
      
    </p>
    <p>
      Velegnede v&#230;rkt&#248;jer inkluderer
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item git / github / bitbucket
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Den lette udgave" ID="ID_1516166047" CREATED="1423650428812" MODIFIED="1424003670023"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Dropbox
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Online latex editorer" ID="ID_1025679996" CREATED="1421760846915" MODIFIED="1424003670024">
<node TEXT="Online latex editorer" ID="ID_244961738" CREATED="1421760841653" MODIFIED="1424003670025"><richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fordele
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Du er k&#248;rende med det samme
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Ulemper
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Du mister kontrol over dokumentet
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      \url{https://www.overleaf.com/}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Latex og eksterne v&#xe6;rkt&#xf8;jer" ID="ID_552287944" CREATED="1412230615220" MODIFIED="1424004075238">
<icon BUILTIN="button_ok"/>
<node TEXT="Biblatex" ID="ID_234781421" CREATED="1423648153204" MODIFIED="1424004075241">
<icon BUILTIN="button_ok"/>
<node TEXT="Biblatex" ID="ID_290157909" CREATED="1423648407010" MODIFIED="1424004075242">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Biblatex er den moderne udgave af bibtex.
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item lettere at bruge
    </p>
    <p>
      \item flere features
    </p>
    <p>
      \item \ldots
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex eksempel" ID="ID_252991048" CREATED="1423648550258" MODIFIED="1424004075243" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{verbatim}
    </p>
    <p style="margin-right: 0px; text-indent: 0px; margin-bottom: 0px; margin-left: 0px; margin-top: 0px">
      \documentclass{article}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[utf8]{inputenc}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[danish]{babel}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \usepackage[backend=biber,
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      &#160;&#160;style=authoryear, natbib=true]{biblatex}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \addbibresource{references.bib}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      <br/>
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \begin{document}
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Du kan citere artikler \citep{Ahmad1998}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Ogs&#229; p&#229; tekstform, \citet{Andersen2000}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      Sidenumre kan medtages \citep[s. 19]{Alchanatis2001}.
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      <br/>
      
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \printbibliography
    </p>
    <p style="margin-right: 0px; margin-bottom: 0px; text-indent: 0px; margin-left: 0px; margin-top: 0px">
      \end{document}
    </p>
    <p>
      \end{verbatim}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex brugsm&#xf8;nster" ID="ID_1156929164" CREATED="1423648550258" MODIFIED="1424004075244" TEXT_SHORTENED="true">
<icon BUILTIN="button_ok"/>
<attribute NAME="options" VALUE="fragile"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Dokumenter der bruger biblatex (med biber som backend) skal overs&#230;ttes p&#229; f&#248;lgende m&#229;de
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item biber
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
    <p>
      Benyttes bibtex som backend, er proceduren
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item bibtex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \item pdflatex
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Bibtex vs. biber" ID="ID_982365190" CREATED="1423648388676" MODIFIED="1424004075244">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Bibtex er et gammelt program fra 1980'erne, som bl.a. kan have problemer med store reference databaser og h&#229;ndterer special tegn d&#229;rligt.
    </p>
    <p>
      \item Biber er en ny opdatering / genskrivning af bibtex, som ikke har disse problemer.
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Biblatex -- ressourcer" ID="ID_1170763852" CREATED="1423648161203" MODIFIED="1424004075245">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item ShareLatex -- Getting Started with Biblatex \\
    </p>
    <p>
      \url{https://www.sharelatex.com/blog/2013/07/31/getting-started-with-biblatex.html}
    </p>
    <p>
      \item Biblatex dokumentation (advarsel $\sim$ 250 sider) \\
    </p>
    <p>
      \url{http://mirror.ox.ac.uk/sites/ctan.org/macros/latex/contrib/biblatex/doc/biblatex.pdf}
    </p>
    <p>
      \item Eksempel p&#229; brug af biblatex (fra tex.stackexchange.com) \\
    </p>
    <p>
      \url{http://tex.stackexchange.com/a/34136/1366}
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>

</richcontent>
</node>
</node>
<node TEXT="H&#xe5;ndtering af referencer" ID="ID_908885201" CREATED="1412230623481" MODIFIED="1424004075246">
<icon BUILTIN="button_ok"/>
<node TEXT="H&#xe5;ndtering af referencer" ID="ID_186270263" CREATED="1412230623481" MODIFIED="1424004075247">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Programmer til at h&#229;ndtere en artikeldatabase
    </p>
  </body>
</html>
</richcontent>
<node TEXT="jabref" ID="ID_143539606" CREATED="1412230635212" MODIFIED="1424004075248">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="mendeley" ID="ID_1695749775" CREATED="1412230642862" MODIFIED="1424004075248">
<icon BUILTIN="button_ok"/>
</node>
<node TEXT="zotero" ID="ID_1050667141" CREATED="1412230645658" MODIFIED="1424004075249">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
<node TEXT="Fra excel til latex tabeller" ID="ID_1998225009" CREATED="1423649449283" MODIFIED="1424004075250">
<icon BUILTIN="button_ok"/>
<node TEXT="Online v&#xe6;rkt&#xf8;jer" ID="ID_1826409784" CREATED="1423649461457" MODIFIED="1424004075251">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item \url{http://ericwood.org/excel2latex/} \\
    </p>
    <p>
      Kan udtr&#230;kke tekst fra .xlsx filer og formattere det som latex tabeller.
    </p>
    <p>
      \item \url{http://www.tablesgenerator.com/} \\
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="L&#xf8;se ender" ID="ID_412841517" CREATED="1421327747419" MODIFIED="1424004075251">
<icon BUILTIN="button_ok"/>
<node TEXT="L&#xf8;se ender" ID="ID_993257159" CREATED="1421327747419" MODIFIED="1424004075252">
<icon BUILTIN="button_ok"/>
<node TEXT="L&#xf8;se ender" ID="ID_179467560" CREATED="1421327747419" MODIFIED="1424004075253">
<icon BUILTIN="button_ok"/>
<node TEXT="hyphenation" ID="ID_997386406" CREATED="1421327752359" MODIFIED="1424004075253">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="Skriv matematik i latex" ID="ID_884758890" CREATED="1421915312705" MODIFIED="1424004075254">
<icon BUILTIN="button_ok"/>
<node TEXT="\url{http://en.wikibooks.org/wiki/LaTeX/Mathematics}" ID="ID_1491762892" CREATED="1421915317169" MODIFIED="1424004075255">
<icon BUILTIN="button_ok"/>
</node>
</node>
<node TEXT="Latex vs. word" ID="ID_1804863539" CREATED="1422518102085" MODIFIED="1424004075256">
<icon BUILTIN="button_ok"/>
<richcontent TYPE="NOTE">

<html>
  <head>
    
  </head>
  <body>
    <p>
      An Efficiency Comparison of Document Preparation Systems Used in Academic Research and Development,
    </p>
    <p>
      Markus Knauff og Jelica Nejasmic
    </p>
    <p>
      
    </p>
    <p>
      \url{http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0115069}
    </p>
    <p>
      
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Indskrive tre eksempler, hver inden for 30 min
    </p>
    <p>
      \begin{itemize}
    </p>
    <p>
      \item Tekst
    </p>
    <p>
      \item Tabeller
    </p>
    <p>
      \item Matematik
    </p>
    <p>
      \end{itemize}
    </p>
    <p>
      \item F&#230;rre fejl i matematik
    </p>
    <p>
      \item Flere fejl i tabeller og tekst
    </p>
    <p>
      \end{itemize}
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="index" ID="ID_151713987" CREATED="1412230650235" MODIFIED="1424004075256">
<icon BUILTIN="button_ok"/>
<node TEXT="index" ID="ID_1036105064" CREATED="1412230650235" MODIFIED="1424004075257">
<icon BUILTIN="button_ok"/>
</node>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
